import React from 'react';

const Description = ({ text }) => {
  return <p className="text-gray-700">{text}</p>;
};

export default Description;